﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logicalskills
{
    class Program
    {
        static void Main(string[] args)
        {
            int MinimumNumber = 1, MaximumNumber = 100;
            PrintNumbers(MinimumNumber, MaximumNumber);
        }

        private static void PrintNumbers(int min, int max)
        {
            for(int i = min; i <= max; i++)
            {
                if(i%3 == 0)
                {
                    Console.WriteLine("fizz");
                }
                else if(i%5 == 0)
                {
                    Console.WriteLine("buzz");
                }
                else if (i % 5 == 0 && i % 3 == 0)
                {
                    Console.WriteLine("fizzbuzz");
                }
                else
                {
                    continue;
                }
            }
        }
    }
}
