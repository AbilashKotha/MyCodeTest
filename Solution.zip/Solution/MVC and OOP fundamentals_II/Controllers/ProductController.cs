﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MVC_and_OOP_fundamentals_II.Controllers
{
    
    public class ProductController : ApiController
    {
        private IOfferService _offerService;

        public ProductController(IOfferService OfferService)
        {
            _offerService = OfferService;
        }

        [HttpGet]
        public  IHttpActionResult  Get()
        {
          return _offerService.GetAllProducts();
        }


    }
}
