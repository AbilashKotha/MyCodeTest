﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC_and_OOP_fundamentals_II.Models
{
    public class Offer
    {
        string OfferName;
        List<Product> Products;

        public Offer(string offerName, List<Product> products)
        {
            OfferName = offerName;
            Products = products;
        }
    }
}