﻿using MVC_and_OOP_fundamentals_II.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVC_and_OOP_fundamentals_II
{
    public interface IOfferService
    {


        List<Product> GetAllProducts();
    }
}
