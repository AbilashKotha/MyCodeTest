﻿using MVC_and_OOP_fundamentals_II.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC_and_OOP_fundamentals_II.Data
{
    public class OfferServices : IOfferService
    {
        private List<Product> Inventory;

        private List<Product> AddDate()
        {
            List<Product> _Inventory = new List<Product>();
            var item1 = new Product("P1", 1000, "p1 desc");
            _Inventory.Add(item1);
            var item2 = new Product("P1", 1000, "p1 desc");
            _Inventory.Add(item2);
            var item3 = new Product("P1", 1000, "p1 desc");
            _Inventory.Add(item3);
            var item4 = new Product("P1", 1000, "p1 desc");
            _Inventory.Add(item4);
            var item5 = new Product("P1", 1000, "p1 desc");
            _Inventory.Add(item5);
            var item6 = new Product("P1", 1000, "p1 desc");
            _Inventory.Add(item6);

            return _Inventory;
        }

        public OfferServices()
        {
            Inventory = AddDate();
        }

        public List<Product> GetAllProducts()
        {
            return Inventory;
        }

        //public Product GetTodayOffers()
        //{
        //    var todayOffer = Offer("ComboPackage1", ){ }
        //}
    }
}