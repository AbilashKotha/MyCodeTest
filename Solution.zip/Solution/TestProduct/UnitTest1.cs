﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net.Http;

namespace TestProduct
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void ProductWithSecondLP()
        {
            var http = new HttpClient();
            http.BaseAddress = "hostname";
            const url = "api/Product";
            http.DefaultRequestHeaders.Accept.Clear(new MedicaTypeFormatters('application/json'));
            var response = http.GetAsync(url);

            // after serializing

            Assert.AreEqual equal();

        }
    }
}
