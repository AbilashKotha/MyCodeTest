﻿ Select * from customers where Name like 'Joe%'

select * from Name from product p
inner join orderproduct op on p.productid = op.productid
inner join order o on o.orderid = op.orderid
inner join customer c on o.customerid = c.customerid
where c.customer name = "Joe" and o.createddate > 11/1/2016

select sum(price) from product p
inner join orderproduct op on p.productid = op.productid
inner join order o on o.orderid = op.orderid
inner join customer c on o.customerid = c.customerid
having c.customer name = "Joe"




